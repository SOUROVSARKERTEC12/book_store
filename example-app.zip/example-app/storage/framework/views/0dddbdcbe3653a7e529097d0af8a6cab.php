<?php $__env->startSection('title'); ?>
books
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-3 ">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title"
            <li class="list-group-item"><b>Title        :</b> <?php echo e($book->title); ?></li>
            <li class="list-group-item"><b>Author       :</b> <?php echo e($book->author); ?></li>
            <li class="list-group-item"><b>ISBN         :</b> <?php echo e($book->isbn); ?></li>
            <li class="list-group-item"><b>Price        :</b> <?php echo e($book->price); ?></li>
            <li class="><?php echo e($book->title); ?></h5>
        </div>
        <ul class="list-group list-group-flush">list-group-item"><b>Availability :</b> <?php echo e($book->availability); ?></li>

        </ul>
        <div class="card-body">
            <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">Back</a>
            <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-primary">Edit</a>
            <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="post" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mysql\data\example-app\resources\views/books/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
books
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Books</h1>
        <!-- create a search bar -->
        <form action="<?php echo e(route('books.search')); ?>" method="get">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="search" placeholder="Search books" aria-label="Recipient's username" aria-describedby="button-addon2">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Search</button>
                </div>
            </div>

    <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary mb-3">Add new book</a>
    <!-- create a download button -->
    <a href="<?php echo e(route('books.generatePDF')); ?>" class="btn btn-primary mb-3">Download</a>
    <table class="table  table-striped">
        <thead class="bg-dark text-white">
            <tr>
                <th>Title</th>
                <th>Author</th>
                <th>ISBN</th>
                <th>Price</th>
                <th>Availability</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($book->title); ?></td>
                <td><?php echo e($book->author); ?></td>
                <td><?php echo e($book->isbn); ?></td>
                <td><?php echo e($book->price); ?></td>
                <td><?php echo e($book->availability); ?></td>
                <td>
                    <a href="<?php echo e(route('books.show', $book->id)); ?>" class="btn btn-sm btn-secondary">View</a>
                    <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="post" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex justify-content-center">
        <?php echo e($books->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mysql\data\example-app\resources\views/books/index.blade.php ENDPATH**/ ?>